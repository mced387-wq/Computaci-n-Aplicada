#script para respaldo
#respaldar /www_dir
#verificar que los sistemas de archivo de origen y destino existan
if [ -d /www_dir ] && [ -d /backup_dir ]; then
 echo "realizando respaldo de /www_dir.. "
 #directorio de origen 
 backup_files="/www_dir/*.*"
 #directorio destino
 dest="/backup_dir"
 #nombre del archivo del backup
 filename="www_dir_bkp_$(date +"%Y%m%d").tar.gz"
 #comando para comprimir archivo
 tar -czvf "$dest/$filename" $backup_files
 echo "respaldo de /www_dir finalizado"
else
 echo "sistema de archivo no exixte no es posible respaldar, verifique"
fi
