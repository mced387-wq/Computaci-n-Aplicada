#script para respaldo
#respaldar /var/logs
#verificar que los sistemas de archivo de origen y destino existan
if [ -d /var/log ] && [ -d /backup_dir ]; then
 echo "realizando respaldo de /var/log.. "
 #directorio de origen 
 backup_files="/var/log/*.*"
 #directorio destino
 dest="/backup_dir"
 #nombre del archivo del backup
 filename="log_bkp_$(date +"%Y%m%d").tar.gz"
 #comando para comprimir archivo
 tar -czvf "$dest/$filename" $backup_files
 echo "respaldo de /var/log finalizado"
else
 echo "sistema de archivo no exixte no es posible respaldar, verifique"
fi
